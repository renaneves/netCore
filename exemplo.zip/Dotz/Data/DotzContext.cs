﻿using Dotz.Entities;
using Dotz.Data.Mapping;
using Microsoft.EntityFrameworkCore;
 
namespace Dotz.Data
{
    public partial class DotzContext : DbContext
    {
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<UsuarioEndereco> UsuarioEnderecos { get; set; }
        public DbSet<UsuarioConsumo> UsuarioConsumos { get; set; }
        public DbSet<Empresa> Empresas { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Produto> Produtos { get; set; }
        public DbSet<UsuarioPedido> UsuarioPedidos { get; set; }
        public DbSet<UsuarioPedidoItem> UsuarioPedidoItems { get; set; }


        public DotzContext(DbContextOptions<DotzContext> options)
            : base(options)
        {
            
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new UsuarioMap());
            modelBuilder.ApplyConfiguration(new UsuarioEnderecoMap());
            modelBuilder.ApplyConfiguration(new UsuarioConsumoMap());
            modelBuilder.ApplyConfiguration(new EmpresaMap());
            modelBuilder.ApplyConfiguration(new CategoriaMap());
            modelBuilder.ApplyConfiguration(new ProdutoMap());
            modelBuilder.ApplyConfiguration(new UsuarioPedidoMap());
            modelBuilder.ApplyConfiguration(new UsuarioPedidoItemMap());

        }
    }
}
