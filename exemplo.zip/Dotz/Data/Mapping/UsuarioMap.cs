﻿using Dotz.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Dotz.Data.Mapping
{ 
    public class UsuarioMap : IEntityTypeConfiguration<Usuario>
    {
        public void Configure(EntityTypeBuilder<Usuario> builder)
        {
            builder.ToTable("Usuario");

            builder.HasKey(c => c.UsuarioId);

            builder.Property(c => c.Nome)
                .HasMaxLength(200);

            builder.Property(c => c.CPF)
                .HasMaxLength(14);

            builder.Property(c => c.Email)
                .HasMaxLength(120);

            builder.Property(c => c.Pass)
                .HasMaxLength(50);

            builder.Ignore(t => t.Token);
        }
    }
}
