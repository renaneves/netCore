﻿using Dotz.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
 
namespace Dotz.Data.Mapping
{
    public class CategoriaMap : IEntityTypeConfiguration<Categoria>
    {
        public void Configure(EntityTypeBuilder<Categoria> builder)
        {
            
            builder.ToTable("Categoria");

            builder.HasKey(c => c.CategoriaId);

            builder.Property(c => c.Nome)
                .HasMaxLength(50);

            builder.HasOne(x => x.CategoriaPai)
                .WithMany()
                .HasForeignKey(x => x.CategoriaPaiId);

            
        }
    }
}
