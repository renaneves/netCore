﻿using Dotz.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Dotz.Data.Mapping
{
    public class UsuarioPedidoMap : IEntityTypeConfiguration<UsuarioPedido>
    {
        public void Configure(EntityTypeBuilder<UsuarioPedido> builder)
        {
            builder.ToTable("Usuario_Pedido");

            builder.HasKey(c => c.Usuario_PedidoId);

            builder.Ignore(t => t.StatusDescricao);

            builder.HasOne(x => x.Endereco)
                .WithMany()
                .HasForeignKey(x => x.Usuario_EnderecoId);




        }
    }
}
