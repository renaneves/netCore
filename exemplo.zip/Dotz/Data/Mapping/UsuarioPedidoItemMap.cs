﻿using Dotz.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Dotz.Data.Mapping
{ 
    public class UsuarioPedidoItemMap : IEntityTypeConfiguration<UsuarioPedidoItem>
    {
        public void Configure(EntityTypeBuilder<UsuarioPedidoItem> builder)
        {
            builder.ToTable("Usuario_Pedido_Item");

            builder.HasKey(c => c.Usuario_Pedido_ItemId);

            builder.HasOne(x => x.Produto)
                .WithMany()
                .HasForeignKey(x => x.ProdutoId);


            
        }
    }
}
