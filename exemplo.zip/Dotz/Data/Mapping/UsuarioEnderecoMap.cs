﻿using Dotz.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Dotz.Data.Mapping
{ 
    public class UsuarioEnderecoMap : IEntityTypeConfiguration<UsuarioEndereco>
    {
        public void Configure(EntityTypeBuilder<UsuarioEndereco> builder)
        {
            builder.ToTable("Usuario_Endereco");

            builder.HasKey(c => c.Usuario_EnderecoId);

            builder.Property(c => c.Logradouro)
                .HasMaxLength(200);

            builder.Property(c => c.Numero)
                .HasMaxLength(10);

            builder.Property(c => c.Complemento)
                .HasMaxLength(80);

            builder.Property(c => c.Bairro)
                .HasMaxLength(200);

            builder.Property(c => c.Cidade)
                .HasMaxLength(200);

            builder.Property(c => c.UF)
                .HasMaxLength(2);

            builder.Property(c => c.CEP)
                .HasMaxLength(9);

            builder.Property(c => c.Nome)
                .HasMaxLength(80);
        }
    }
}
