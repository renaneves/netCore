﻿using Dotz.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
 
namespace Dotz.Data.Mapping
{
    public class EmpresaMap : IEntityTypeConfiguration<Empresa>
    {
        public void Configure(EntityTypeBuilder<Empresa> builder)
        {
            builder.ToTable("Empresa");

            builder.HasKey(c => c.EmpresaId);

            builder.Property(c => c.Nome)
                .HasMaxLength(120);

            builder.Property(c => c.CNPJ)
                .HasMaxLength(18);

            
        }
    }
}
