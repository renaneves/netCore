﻿using Dotz.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
 
namespace Dotz.Data.Mapping
{
    public class UsuarioConsumoMap : IEntityTypeConfiguration<UsuarioConsumo>
    {        
        public void Configure(EntityTypeBuilder<UsuarioConsumo> builder)
        {
            builder.ToTable("Usuario_Consumo");

            builder.HasKey(c => c.Usuario_ConsumoId);

            builder.HasOne(x => x.Empresa)
                .WithMany()
                .HasForeignKey(x => x.EmpresaId);
        }
    }
}
