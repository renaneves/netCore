﻿using System.ComponentModel.DataAnnotations;

namespace Dotz.Entities
{
    public class UsuarioEndereco
    { 
        public int Usuario_EnderecoId { get; set; }
        public int UsuarioId { get; set; }
        [Required]
        public string Logradouro { get; set; }
        [Required]
        public string Numero { get; set; }
        public string Complemento { get; set; }
        [Required]
        public string Bairro { get; set; }
        [Required]
        public string Cidade { get; set; }
        [Required]
        public string UF { get; set; }
        [Required]
        public string CEP { get; set; }
        [Required]
        public string Nome { get; set; }
    }
}
