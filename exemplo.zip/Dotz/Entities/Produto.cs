﻿using System.Collections.Generic;

namespace Dotz.Entities
{
    public class Produto
    { 
        public int ProdutoId { get; set; }
        public string Nome { get; set; }        
        public int Pontos { get; set; }
        public int Estoque { get; set; }
        public bool DisponivelTroca { get; set; }

        public int CategoriaId { get; set; }
        public virtual Categoria Categoria { get; set; }
    }
}
