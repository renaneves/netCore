﻿using System;

namespace Dotz.Entities
{
    public class UsuarioConsumo
    { 
        public int Usuario_ConsumoId { get; set; }     
        public int UsuarioId { get; set; }
        public DateTime DtConsumo { get; set; }
        public DateTime DtExpiracao { get; set; }
        public int Pontos { get; set; }
        public int PontosResgatado { get; set; }
        public decimal Valor { get; set; }

        public int EmpresaId { get; set; }
        public virtual Empresa Empresa { get; set; }
    }
}
