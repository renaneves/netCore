﻿using Dotz.Entities.Enum;
using System;
using System.Collections.Generic;

namespace Dotz.Entities
{
    public class UsuarioPedido
    {		
        public int Usuario_PedidoId { get; set; }
        public int UsuarioId { get; set; }
        public DateTime DtPedido { get; set; }
        public StatusPedido Status { get; set; }
        public string StatusDescricao {
            get {
                    return Status.ToString();
                } }

        public int Usuario_EnderecoId { get; set; }
        public virtual UsuarioEndereco Endereco { get; set; }

        public virtual IEnumerable<UsuarioPedidoItem> Itens { get; set; }

    }
}
