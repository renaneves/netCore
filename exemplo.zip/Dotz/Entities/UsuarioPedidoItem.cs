﻿namespace Dotz.Entities
{
    public class UsuarioPedidoItem
    { 
        public int Usuario_Pedido_ItemId { get; set; }
        public int Usuario_PedidoId { get; set; }
        public int Pontos { get; set; }
        public int ProdutoId { get; set; }
        public int Quantidade { get; set; }
        public Produto Produto { get; set; }
    }
}
