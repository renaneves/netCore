﻿namespace Dotz.Entities.Enum
{
    public enum StatusPedido : int
    { 
        Aberto = 0,
        Pago = 1,
        Entregue = 2
    }
}
