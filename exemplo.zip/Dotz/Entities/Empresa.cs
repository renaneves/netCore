﻿using System.Collections.Generic;

namespace Dotz.Entities
{
    public class Empresa
    { 
        public int EmpresaId { get; set; }
        public string Nome { get; set; }
        public string CNPJ { get; set; }
    }
}
