﻿using Dotz.Entities;
using Dotz.Helpers;
using Dotz.Interfaces.Services;
using Dotz.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
 
namespace Dotz.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private IUsuarioService _usuarioService;

        public UsuarioController(IUsuarioService usuarioService)
        {
            _usuarioService = usuarioService;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody]Login login)
        {
            var user = _usuarioService.Authenticate(login.Usuario, login.Pass);

            if (user == null)
                return BadRequest(new { message = "Usuário ou senha inválido!" });

            return Ok(user);
        }

        [HttpPost("novo")]
        public IActionResult CriarUsuario([FromBody]Usuario usuario)
        {
            string msg = _usuarioService.Novo(usuario);

            if (!string.IsNullOrEmpty(msg))
            {
                return BadRequest(new { message = msg });
            } 

            return Ok(usuario);
        }

        [Authorize]
        [HttpGet("saldo")]
        public async Task<IActionResult> Saldo()
        {
            int usuarioId = Convert.ToInt32(Authentication.RetornaUser(User));
            var saldo = _usuarioService.Saldo(usuarioId);
            return Ok(saldo);
        }

        [Authorize]
        [HttpGet("extrato")]
        public async Task<IActionResult> Extrato()
        {
            int usuarioId = Convert.ToInt32(Authentication.RetornaUser(User));
            var extrato = await _usuarioService.Extrato(usuarioId);
            return Ok(extrato);
        }
    }
}