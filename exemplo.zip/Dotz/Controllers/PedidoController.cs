﻿using Dotz.Entities;
using Dotz.Helpers;
using Dotz.Interfaces.Services;
using Dotz.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
 
namespace Dotz.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private IPedidoService _pedidoService;
        public PedidoController(IPedidoService pedidoService)
        {
            _pedidoService = pedidoService;
        }

        [Authorize]
        [HttpGet("lista")]
        public async Task<IActionResult> Lista()
        {
            int usuarioId = Convert.ToInt32(Authentication.RetornaUser(User));
            var pedidos = await _pedidoService.Lista(usuarioId);
            return Ok(pedidos);
        }

        [Authorize]
        [HttpPost("resgateproduto")]
        public async Task<IActionResult> ResgateProduto([FromBody]Resgate resgate)
        {
            string msg = string.Empty;
            try
            {
                
                int usuarioId = Convert.ToInt32(Authentication.RetornaUser(User));

                UsuarioPedido pedido = new UsuarioPedido();
                pedido.UsuarioId = usuarioId;

                List<UsuarioPedidoItem> itens = new List<UsuarioPedidoItem>();
                foreach (var produto in resgate.Produtos)
                {
                    itens.Add(
                        new UsuarioPedidoItem()
                        {
                            ProdutoId = produto.ProdutoId,
                            Quantidade = produto.Quantidade
                        }
                        );
                }
                pedido.Itens = itens;
                pedido.Usuario_EnderecoId = resgate.EnderecoEntrega;

                msg = await _pedidoService.AdicionaPedido(pedido);
                if (!string.IsNullOrEmpty(msg))
                {
                    return BadRequest(msg);
                }
                return Ok(pedido);
            } catch
            {
                return BadRequest("Não foi possiver dar continuidade ao seu pedido!");
            }
            
        }
    }
}