﻿using Dotz.Helpers;
using Dotz.Interfaces.Services;
using Dotz.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
 
namespace Dotz.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProdutoController : ControllerBase
    {
        private IProdutoService _produtoService;
        public ProdutoController(IProdutoService produtoService)
        {
            _produtoService = produtoService;
        }

        [Authorize]
        [HttpGet("lista")]
        public async Task<IActionResult> ListaProduto()
        {
            int usuarioId = Convert.ToInt32(Authentication.RetornaUser(User));
            var produtos = await _produtoService.Disponivel(usuarioId);
            return Ok(produtos);
        }

        
    }
}