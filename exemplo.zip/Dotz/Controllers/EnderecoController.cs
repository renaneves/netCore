﻿using Dotz.Entities;
using Dotz.Helpers;
using Dotz.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
 
namespace Dotz.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnderecoController : ControllerBase
    {
        private IUsuarioEnderecoService _usuarioEnderecoService;
        public EnderecoController(IUsuarioEnderecoService usuarioEnderecoService)
        {
            _usuarioEnderecoService = usuarioEnderecoService;
        }

        [Authorize]
        [HttpPost("adicionarouatualizar")]
        public async Task<IActionResult> AdicionarouAtualizar([FromBody]UsuarioEndereco endereco)
        {
            string usuarioId = Authentication.RetornaUser(User);
            endereco.UsuarioId = Convert.ToInt32(usuarioId);
            await _usuarioEnderecoService.AddOrUpdade(endereco);
            return Ok(endereco);
        }

        [Authorize]
        [HttpGet("retornatodos")]
        public async Task<IActionResult> GetAll()
        {
            int usuarioId = Convert.ToInt32(Authentication.RetornaUser(User));
            var enderecos = await _usuarioEnderecoService.GetAll(usuarioId);
            return  Ok(enderecos);
        }
    }
}