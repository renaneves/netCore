﻿using Dotz.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
 
namespace Dotz.Interfaces.Services
{
    public interface IUsuarioService
    {
        Usuario Authenticate(string username, string password);
        string Novo(Usuario usuario);
        int Saldo(int usuarioId);
        Task<IEnumerable<UsuarioConsumo>> Extrato(int usuarioId);

    }
}
