﻿using Dotz.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
 
namespace Dotz.Interfaces.Services
{
    public interface IUsuarioEnderecoService
    {
        Task AddOrUpdade(UsuarioEndereco endereco);
        Task<IEnumerable<UsuarioEndereco>> GetAll(int usuarioId);
    }
}
