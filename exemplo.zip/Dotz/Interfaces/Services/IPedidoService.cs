﻿using Dotz.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

 
namespace Dotz.Interfaces.Services
{
    public interface IPedidoService
    {
        Task<IEnumerable<UsuarioPedido>> Lista(int usuarioId);
        Task<string> AdicionaPedido(UsuarioPedido pedido);
    }
}
