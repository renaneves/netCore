﻿using Dotz.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
 
namespace Dotz.Interfaces.Services
{
    public interface IProdutoService
    {
        Task<IEnumerable<Produto>> Disponivel(int usuarioId);
    }
}
