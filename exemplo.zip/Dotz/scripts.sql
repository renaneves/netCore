CREATE TABLE Usuario (
     UsuarioId Int NOT NULL AUTO_INCREMENT,
     Nome VARCHAR(200) NOT NULL,
	 CPF VARCHAR(14) NOT NULL,
	 Email VARCHAR(120) NOT NULL,
	 Pass VARCHAR(200) NOT NULL,
     PRIMARY KEY (UsuarioId)
);

CREATE INDEX idxUsuario ON Usuario (CPF, Email);

CREATE TABLE Usuario_Endereco (
     Usuario_EnderecoId Int NOT NULL AUTO_INCREMENT,
     UsuarioId Int NOT NULL,
	 Logradouro VARCHAR(200),
	 Numero VARCHAR(10),
	 Complemento VARCHAR(80),
	 Bairro VARCHAR(200),
	 Cidade VARCHAR(200),
	 UF VARCHAR(2),
	 CEP VARCHAR(9),
	 Nome VARCHAR(80),
     PRIMARY KEY (Usuario_EnderecoId)
);

CREATE INDEX idxUsuario_Endereco ON Usuario_Endereco (UsuarioId);

CREATE TABLE Empresa (
     EmpresaId Int NOT NULL AUTO_INCREMENT,
     Nome VARCHAR(120) NOT NULL,
	 CNPJ VARCHAR(18) NOT NULL,
	 Logradouro VARCHAR(200),
	 Numero VARCHAR(10),
	 Complemento VARCHAR(80),
	 Bairro VARCHAR(200),
	 Cidade VARCHAR(200),
	 UF VARCHAR(2),
	 CEP VARCHAR(9),
     PRIMARY KEY (EmpresaId)
);

INSERT INTO Empresa (`Nome`, `CNPJ`, `Logradouro`, `Numero`, `Bairro`, `Cidade`, `UF`, `CEP`) VALUES ('Emp 1', '00.000.000/0001-00', 'Rua Tal', '10', 'Vila', 'Cruzeiro', 'SP', '12700-000');
INSERT INTO Empresa (`Nome`, `CNPJ`, `Logradouro`, `Numero`, `Bairro`, `Cidade`, `UF`, `CEP`) VALUES ('Emp 2', '11.111.111/1111-11', 'Rua Tal', '10', 'Vila', 'Cruzeiro', 'SP', '12700-000');

CREATE TABLE Categoria (
     CategoriaId Int NOT NULL AUTO_INCREMENT,
     Nome VARCHAR(50) NOT NULL,
	 CategoriaPaiId Int,
     PRIMARY KEY (CategoriaId)
);

INSERT INTO `Categoria` (`Nome`) VALUES ('Decoração');
INSERT INTO `Categoria` (`Nome`,`CategoriaPaiId`) VALUES ('Almofadas e Capas',1);
INSERT INTO `Categoria` (`Nome`,`CategoriaPaiId`) VALUES ('Almofadas',2);
INSERT INTO `Categoria` (`Nome`) VALUES ('Combustivel');

CREATE TABLE Produto (
     ProdutoId Int NOT NULL AUTO_INCREMENT,
     Nome VARCHAR(80) NOT NULL,
	 CategoriaId Int,
	 Pontos Int,
	 Estoque Int,
	 DisponivelTroca boolean,
     PRIMARY KEY (ProdutoId)
);

INSERT INTO `Produto` (`Nome`, `CategoriaId`, `Pontos`, `Estoque`, `DisponivelTroca`) VALUES ('Almofada Candy Chocolate M', '3', '3890', '10', '1');
INSERT INTO `Produto` (`Nome`, `CategoriaId`, `Pontos`, `Estoque`, `DisponivelTroca`) VALUES ('Kit Almofada Com Porta Pipoca 1 Balde + 2 Copos Netflix Com Bolso', '3', '8490', '10', '1');
INSERT INTO `Produto` (`Nome`, `CategoriaId`, `Pontos`, `Estoque`, `DisponivelTroca`) VALUES ('Gasolina', '4', '1', '0', '0');

CREATE TABLE Usuario_Consumo (
	 Usuario_ConsumoId Int NOT NULL AUTO_INCREMENT,
	 EmpresaId Int,
	 UsuarioId Int,
	 DtConsumo Datetime,
	 DtExpiracao Datetime,
	 Pontos Int,
	 PontosResgatado Int,
	 Valor decimal(12,2),
	 PRIMARY KEY (Usuario_ConsumoId)
);

CREATE INDEX idxUsuario_Consumo ON Usuario_Consumo (UsuarioId);

INSERT INTO `Usuario_Consumo` (`EmpresaId`, `UsuarioId`, `DtConsumo`, `DtExpiracao`, `Pontos`, `PontosResgatado`, `Valor`) VALUES ('1', '1', '2019-01-12', '2019-02-12', '18000', '0', '180');
INSERT INTO `Usuario_Consumo` (`EmpresaId`, `UsuarioId`, `DtConsumo`, `DtExpiracao`, `Pontos`, `PontosResgatado`, `Valor`) VALUES ('2', '1', '2019-02-13', '2019-03-13', '25000', '0', '250');

CREATE TABLE Usuario_Pedido (
	 Usuario_PedidoId Int NOT NULL AUTO_INCREMENT,
	 UsuarioId Int,
	 DtPedido Datetime,
	 Status Int,
	 Usuario_EnderecoId Int,
	 PRIMARY KEY (Usuario_PedidoId)
);

CREATE INDEX idxUsuario_Pedido ON Usuario_Pedido (UsuarioId);

CREATE TABLE Usuario_Pedido_Item (
	 Usuario_Pedido_ItemId Int NOT NULL AUTO_INCREMENT,
     Usuario_PedidoId Int NOT NULL,
	 ProdutoId Int NOT NULL,
     Pontos Int,
	 Quantidade Int,
	 PRIMARY KEY (Usuario_Pedido_ItemId)
);