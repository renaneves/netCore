﻿using System.ComponentModel.DataAnnotations;

namespace Dotz.Model
{ 
    public class Login
    {
        [Required]
        public string Usuario { get; set; }
        [Required]
        public string Pass { get; set; }
    }
}
