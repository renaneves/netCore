﻿using System.Collections.Generic;
 
namespace Dotz.Model
{
    public class Resgate
    {
        public List<ProdutoResgate> Produtos { get; set; }
        public int EnderecoEntrega { get; set; }
    }

    public class ProdutoResgate
    {
        public int ProdutoId { get; set; }
        public int Quantidade { get; set; }
    }
}
