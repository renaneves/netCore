﻿using System;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
 
namespace Dotz.Helpers
{
    public static class Authentication
    {
        public static string RetornaUser(ClaimsPrincipal principal)
        {
            string user = null;            
            if (principal == null)
                return null;
            ClaimsIdentity identity = null;
            try
            {
                identity = (ClaimsIdentity)principal.Identity;
            }
            catch (NullReferenceException)
            {
                return null;
            }
            Claim usernameClaim = identity.FindFirst(ClaimTypes.NameIdentifier);
            user = usernameClaim.Value;
            return user;
        }

        public static string GetHash(string text)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(text));
                var hash = BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
                return hash;
            }
        }
    }
}
