﻿namespace Dotz.Helpers
{ 
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
