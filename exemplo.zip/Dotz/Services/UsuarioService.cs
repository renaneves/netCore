﻿using Dotz.Data;
using Dotz.Entities;
using Dotz.Helpers;
using Dotz.Interfaces.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
 
namespace Dotz.Services
{
    public class UsuarioService : IUsuarioService
    {
        private readonly AppSettings _appSettings;
        private readonly DotzContext _contexto;

        public UsuarioService(IOptions<AppSettings> appSettings, DotzContext contexto)
        {
            _appSettings = appSettings.Value;
            _contexto = contexto;
        }

        public Usuario Authenticate(string username, string password)
        {
            var user = _contexto.Usuarios.SingleOrDefault(x => x.CPF == username && x.Pass == Authentication.GetHash(password));
            if (user == null)
                return null;

            var signinKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_appSettings.Secret));
            var signInCredentials = new SigningCredentials(signinKey, SecurityAlgorithms.HmacSha256Signature);
            var claims = new Claim[] {
                new Claim(JwtRegisteredClaimNames.Sub,user.UsuarioId.ToString())
            };
            var jwt = new JwtSecurityToken(claims: claims, signingCredentials: signInCredentials);
            var encodedJwt = new JwtSecurityTokenHandler().WriteToken(jwt);
            user.Token = encodedJwt;

            user.UsuarioId = 0;
            user.Pass = null;

            return user;
        }

        public string Novo(Usuario usuario)
        {
            try
            {
                Regex rg = new Regex(@"^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$");
                if (!rg.IsMatch(usuario.Email))
                {
                    return "Informe um email valido!";
                }

                if (_contexto.Usuarios.Where(u => u.Email == usuario.Email).Count()> 0)
                {
                    return "Email já cadastrado!";
                }

                if (_contexto.Usuarios.Where(u => u.CPF == usuario.CPF).Count() > 0)
                {
                    return "CPF já cadastrado!";
                }

                usuario.Pass = Authentication.GetHash(usuario.Pass);

                _contexto.Usuarios.Add(usuario);
                _contexto.SaveChanges();
                usuario.Pass = "";
                return "";
            } catch(Exception ex)
            {
                return "Ocorreu um erro ao tentar cadastrar novo usuário!";
            }            
        }

        public  int Saldo(int usuarioId)
        {
            int saldo = 0;
            try
            {
                var consumo = _contexto.UsuarioConsumos.Where(x => x.UsuarioId == usuarioId && x.DtExpiracao >= DateTime.Now).ToList();
                int pontos = consumo.Sum(x => x.Pontos);
                int pontosResgatado = consumo.Sum(x => x.PontosResgatado);
                return pontos - pontosResgatado;

            } catch(Exception ex)
            {

            }
            
            return saldo;
        }

        public async Task<IEnumerable<UsuarioConsumo>> Extrato(int usuarioId)
        {
            try
            {
                var consumo = await _contexto
                    .UsuarioConsumos
                    .Include(x => x.Empresa)
                    .Where(x => x.UsuarioId == usuarioId).ToListAsync();
                return consumo;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

    }
}
