﻿using Dotz.Data;
using Dotz.Entities;
using Dotz.Interfaces.Services;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
 
namespace Dotz.Services
{
    public class ProdutoService : IProdutoService
    {
        private readonly DotzContext _contexto;

        public ProdutoService(DotzContext contexto)
        {
            _contexto = contexto;
        }

        public async Task<IEnumerable<Produto>> Disponivel(int usuarioId)
        {
            var produtos = await _contexto
                .Produtos
                .Include(x => x.Categoria)
                .ThenInclude(g => g.CategoriaPai)
                .ThenInclude(g => g.CategoriaPai.CategoriaPai)
                .Where(x => x.DisponivelTroca == true && x.Estoque > 0).ToListAsync();
            return produtos;
        }


    }
}
