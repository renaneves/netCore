﻿using Dotz.Data;
using Dotz.Entities;
using Dotz.Interfaces.Services;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
 
namespace Dotz.Services
{
    public class UsuarioEnderecoService : IUsuarioEnderecoService
    {       
        private readonly DotzContext _contexto;

        public UsuarioEnderecoService(DotzContext contexto)
        {
            _contexto = contexto;
        }

        public async Task AddOrUpdade(UsuarioEndereco endereco)
        {
            if (endereco.Usuario_EnderecoId != 0)
            {
                _contexto.Entry(endereco).State = EntityState.Modified;
            }
            _contexto.UsuarioEnderecos.Attach(endereco);
            await _contexto.SaveChangesAsync();
        }

        public async Task<IEnumerable<UsuarioEndereco>> GetAll(int usuarioId)
        {            
            return await _contexto.UsuarioEnderecos.Where(x => x.UsuarioId == usuarioId).ToListAsync();
        }
    }
}
