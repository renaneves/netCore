﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dotz.Data;
using Dotz.Entities;
using Dotz.Helpers;
using Dotz.Interfaces.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
 
namespace Dotz.Services
{
    public class PedidoService : IPedidoService
    {
        private readonly IOptions<AppSettings> _appSettings;
        private readonly DotzContext _contexto;

        public PedidoService(IOptions<AppSettings> appSettings, DotzContext contexto)
        {
            _appSettings = appSettings;
            _contexto = contexto;
        }

        public async Task<IEnumerable<UsuarioPedido>> Lista(int usuarioId)
        {
            var pedidos = await _contexto
                .UsuarioPedidos
                .Include(x => x.Endereco)
                .Include(x => x.Itens)
                .ThenInclude(i => i.Produto)
                .Where(x => x.UsuarioId == usuarioId).ToListAsync();
            return pedidos;
        }

        public async Task<string> AdicionaPedido(UsuarioPedido pedido)
        {
            _contexto.Database.BeginTransaction();
            int pontos = 0;
            try
            {
                foreach(var item in pedido.Itens)
                {
                    var produto = _contexto.Produtos.FirstOrDefault(p => p.ProdutoId == item.ProdutoId);
                    item.Pontos = produto.Pontos * item.Quantidade;
                    item.Usuario_PedidoId = pedido.Usuario_PedidoId;
                    pontos += item.Pontos;

                    //Verifica se existe produto em estoque
                    if (produto.Estoque < item.Quantidade)
                    {
                        _contexto.Database.RollbackTransaction();
                        return "Não foi possiver dar continuidade ao seu pedido!";
                    }
                    _contexto.Entry(produto).State = EntityState.Modified;
                    produto.Estoque -= item.Quantidade;
                    _contexto.Produtos.Attach(produto);
                    await _contexto.SaveChangesAsync();
                }
                pedido.DtPedido = DateTime.Now;
                pedido.Status = 0;

                //verifica se cliente tem pontos
                UsuarioService usuarioService = new UsuarioService(_appSettings, _contexto);
                var saldo = usuarioService.Saldo(pedido.UsuarioId);
                if (saldo < pontos)
                {
                    _contexto.Database.RollbackTransaction();
                    return "Pontos insuficientes para realizar a troca!";
                }

                //Subtrai pontos
                var listaconsumo = _contexto.UsuarioConsumos.Where(x => x.UsuarioId == pedido.UsuarioId && x.DtExpiracao >= DateTime.Now).ToList();
                foreach(var consumo in listaconsumo)
                {
                    int diff = consumo.Pontos - consumo.PontosResgatado;
                    if (diff > 0)
                    {
                        if (diff > pontos)
                        {
                            consumo.PontosResgatado += pontos;
                            pontos = 0;
                        } else
                        {
                            consumo.PontosResgatado += diff;
                            pontos -= diff;
                        }
                    }

                    if (pontos == 0)
                    {
                        break;
                    }
                }

                _contexto.UsuarioPedidos.Add(pedido);
                await _contexto.SaveChangesAsync();

                _contexto.Database.CommitTransaction();
                return "";
            } catch
            {
                _contexto.Database.RollbackTransaction();
                return "Não foi possiver dar continuidade ao seu pedido!";
            }
        }
    }
}
